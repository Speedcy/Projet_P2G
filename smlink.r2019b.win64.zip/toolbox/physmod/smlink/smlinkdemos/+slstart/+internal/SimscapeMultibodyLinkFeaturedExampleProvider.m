classdef SimscapeMultibodyLinkFeaturedExampleProvider < slstart.internal.FeaturedExampleProvider
    % Stub implementation of slstart.internal.FeaturedExampleProvider for
    % a product with no feature examples.

    % Copyright 2015 The MathWorks, Inc.

    properties (GetAccess = public, SetAccess = private)
        % The customer visible product name this example ships with
        Product = 'Simscape Multibody Link';

        % The short name for this product as used by the Help Browser.
        ProductShortName = 'physmod/smlink';

        % This product currently has no featured examples.
        FeaturedExamples = {};
    end
end
